<?php $a = "world" ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<?php 
	echo !extension_loaded('openssl')?"Not Available":"Available";
	$to = ""; //the recieving email address
	$subject = "hello";
	$content = "world";
	require("PHPMailer/src/PHPMailer.php");
	require("PHPMailer/src/SMTP.php");
	require("PHPMailer/src/Exception.php");
	$mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->isSMTP(); // enable SMTP
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;
    $mail->SMTPDebug = 2;

    $mail->Username = ""; //the sending email address
    $mail->Password = "";//password of the sending email
    $mail->From = ""; //name of the sending email
    $mail->FromName = "no_reply@mercari.com";
    $mail->AddAddress($to); 
    $mail->WordWrap = 50; 
    $mail->IsHTML(true);
    $mail->CharSet="utf-8";
    $mail->Subject =$subject;
    $mail->Body = $content;

	if($mail->Send()){
		echo "success";
	}else{
		echo $mail->ErrorInfo;
	}

?>
	
</body>
</script>
</html>